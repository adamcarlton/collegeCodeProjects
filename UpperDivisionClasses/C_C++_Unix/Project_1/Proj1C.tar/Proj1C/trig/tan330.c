#include <math330.h>
#include <math.h>

double tan330(double angle)
{
    return tan(angle);
}
