#include <source.h>

Image*
Source::GetOutput(){
    return &img;
}
