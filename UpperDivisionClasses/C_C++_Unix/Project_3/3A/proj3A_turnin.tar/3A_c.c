#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    unsigned char red;
    unsigned char green;
    unsigned char blue;
} Pixel;

typedef struct
{
    int height;
    int width;
    Pixel *pixels;
} Image;


Image *
ReadImage(char *filename)
{
    Image *img = malloc(sizeof(Image));
    FILE *f_in = fopen(filename, "rb");
    fscanf(f_in, "P6\n%d %d\n255\n", &(img->width), &(img->height));
    img->pixels = malloc(img->width * img->height *sizeof(Pixel));
    fread(img->pixels, sizeof(Pixel), img->width * img->height, f_in);
    fclose(f_in);
    return img;
}


void WriteImage(Image *img, char *filename)
{
    FILE *picture = fopen(filename, "w");
    fprintf(picture, "P6\n%d %d\n255\n", img->width, img->height);
    fwrite(img->pixels, sizeof(Pixel), img->width * img->height, picture);
    fclose(picture);

}

Image *
YellowDiagonal(Image *input)
{
    int i,j;
    for(i = 0; i < input->width; i++){
        for(j = 0; j < input->height; j++){
            if(i==j){
                input->pixels[j*input->width+i].red = 255;
                input->pixels[j*input->width+i].green = 255;
                input->pixels[j*input->width+i].blue = 0;
            }
        }
    }
    return input;
}

int main(int argc, char *argv[])
{
    Image *img = ReadImage(argv[1]);
    Image *yellowImg = YellowDiagonal(img);
    WriteImage(yellowImg, argv[2]);

    free(img->pixels);
    free(img);
}
