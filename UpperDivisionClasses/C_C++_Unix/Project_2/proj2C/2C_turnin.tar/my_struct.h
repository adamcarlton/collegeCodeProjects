/* This file should contain your struct definitions for Circle, Triangle, and 
   Rectangle */
typedef struct Circle
{
    double x;
    double y;
    double radius;
} Circle;

typedef struct Rectangle
{
    double minX;
    double minY;
    double maxX;
    double maxY;
} Rectangle;

typedef struct Triangle
{
    double pt1X;
    double pt2X;
    double maxY;
    double minY;
} Triangle;


